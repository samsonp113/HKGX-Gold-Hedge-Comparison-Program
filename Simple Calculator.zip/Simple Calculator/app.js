// Enhanced Gold Futures Hedging Calculator with Time Tracking and Save Functionality

class GoldFuturesCalculator {
    constructor() {
        this.contractSize = 100; // troy ounces per COMEX contract
        this.savedCalculations = [];
        this.currentResults = {
            settlement: null,
            buyback: null
        };
        this.initEventListeners();
        this.updateComparisonTable();
        console.log('Gold Futures Calculator initialized');
    }

    initEventListeners() {
        // Settlement form
        const settlementForm = document.getElementById('settlementForm');
        if (settlementForm) {
            settlementForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Settlement form submitted');
                this.calculateSettlement();
            });
        }

        // Buyback form
        const buybackForm = document.getElementById('buybackForm');
        if (buybackForm) {
            buybackForm.addEventListener('submit', (e) => {
                e.preventDefault();
                console.log('Buyback form submitted');
                this.calculateBuyback();
            });
        }

        // Save buttons
        const saveSettlementBtn = document.getElementById('save-settlement');
        const saveBuybackBtn = document.getElementById('save-buyback');
        
        if (saveSettlementBtn) {
            saveSettlementBtn.addEventListener('click', () => this.saveCalculation('settlement'));
        }
        
        if (saveBuybackBtn) {
            saveBuybackBtn.addEventListener('click', () => this.saveCalculation('buyback'));
        }

        // Export and clear buttons
        const exportBtn = document.getElementById('export-csv');
        const clearBtn = document.getElementById('clear-all');
        
        if (exportBtn) {
            exportBtn.addEventListener('click', () => this.exportToCSV());
        }
        
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearAllCalculations());
        }

        // Date and time validation
        this.setupDateTimeValidation();
    }

    setupDateTimeValidation() {
        // Settlement date/time validation
        const entryDate1 = document.getElementById('entry-date-1');
        const entryTime1 = document.getElementById('entry-time-1');
        const exitDate1 = document.getElementById('exit-date-1');
        const exitTime1 = document.getElementById('exit-time-1');
        
        if (entryDate1 && exitDate1 && entryTime1 && exitTime1) {
            const validateSettlement = () => {
                this.validateDateTime(entryDate1, entryTime1, exitDate1, exitTime1, 'Exit date/time must be after entry date/time');
            };
            entryDate1.addEventListener('change', validateSettlement);
            entryTime1.addEventListener('change', validateSettlement);
            exitDate1.addEventListener('change', validateSettlement);
            exitTime1.addEventListener('change', validateSettlement);
        }

        // Buyback date/time validation
        const entryDate2 = document.getElementById('entry-date-2');
        const entryTime2 = document.getElementById('entry-time-2');
        const exitDate2 = document.getElementById('exit-date-2');
        const exitTime2 = document.getElementById('exit-time-2');
        
        if (entryDate2 && exitDate2 && entryTime2 && exitTime2) {
            const validateBuyback = () => {
                this.validateDateTime(entryDate2, entryTime2, exitDate2, exitTime2, 'Exit date/time must be after entry date/time');
            };
            entryDate2.addEventListener('change', validateBuyback);
            entryTime2.addEventListener('change', validateBuyback);
            exitDate2.addEventListener('change', validateBuyback);
            exitTime2.addEventListener('change', validateBuyback);
        }
    }

    validateDateTime(entryDateEl, entryTimeEl, exitDateEl, exitTimeEl, errorMessage) {
        if (!entryDateEl || !entryTimeEl || !exitDateEl || !exitTimeEl) return true;
        
        const entryDateTime = this.combineDateTime(entryDateEl.value, entryTimeEl.value);
        const exitDateTime = this.combineDateTime(exitDateEl.value, exitTimeEl.value);

        if (entryDateEl.value && exitDateEl.value && entryTimeEl.value && exitTimeEl.value) {
            if (exitDateTime <= entryDateTime) {
                this.showError(exitDateEl, errorMessage);
                return false;
            } else {
                this.clearError(exitDateEl);
                return true;
            }
        }
        return true;
    }

    combineDateTime(dateStr, timeStr) {
        if (!dateStr || !timeStr) return null;
        return new Date(`${dateStr}T${timeStr}`);
    }

    calculatePreciseDaysDifference(entryDate, entryTime, exitDate, exitTime) {
        const entryDateTime = this.combineDateTime(entryDate, entryTime);
        const exitDateTime = this.combineDateTime(exitDate, exitTime);
        
        if (!entryDateTime || !exitDateTime) return 0;
        
        const diffTime = exitDateTime - entryDateTime;
        const diffDays = diffTime / (1000 * 60 * 60 * 24); // Convert to days with decimal precision
        
        return Math.max(diffDays, 0.001); // Ensure minimum positive value
    }

    showError(element, message) {
        if (!element) return;
        
        element.style.borderColor = 'var(--color-error)';
        
        // Remove existing error message
        const existingError = element.parentNode.querySelector('.error-message');
        if (existingError) {
            existingError.remove();
        }

        // Add new error message
        const errorDiv = document.createElement('div');
        errorDiv.className = 'error-message show';
        errorDiv.textContent = message;
        element.parentNode.appendChild(errorDiv);
    }

    clearError(element) {
        if (!element) return;
        
        element.style.borderColor = '';
        const errorMessage = element.parentNode.querySelector('.error-message');
        if (errorMessage) {
            errorMessage.remove();
        }
    }

    // Corrected calculation methods following the specified formulas
    calculateInitialPremium(futuresPrice, spotPrice, contracts) {
        return (futuresPrice - spotPrice) * (contracts * this.contractSize);
    }

    calculateExitPremium(futuresPrice, spotPrice, contracts) {
        return (futuresPrice - spotPrice) * (contracts * this.contractSize);
    }

    calculateNetPremium(initialPremium, exitPremium) {
        return initialPremium - exitPremium;
    }

    calculatePortfolioValueAtExit(exitSpotPrice, contracts) {
        return exitSpotPrice * contracts * this.contractSize;
    }

    calculateBaseReturn(netPremium, portfolioValueAtExit) {
        if (portfolioValueAtExit === 0) return 0;
        return netPremium / portfolioValueAtExit;
    }

    calculateAnnualizedReturn(baseReturn, days) {
        if (days === 0) return 0;
        return (baseReturn / days) * 360;
    }

    calculatePremiumPerContract(netPremium, contracts) {
        return netPremium / contracts;
    }

    formatCurrency(amount) {
        return new Intl.NumberFormat('en-US', {
            style: 'currency',
            currency: 'USD',
            minimumFractionDigits: 2,
            maximumFractionDigits: 2
        }).format(amount);
    }

    formatPercentage(percentage, precision = 4) {
        return `${(percentage * 100).toFixed(precision)}%`;
    }

    formatDays(days) {
        return `${days.toFixed(2)} days`;
    }

    formatDateTime(dateStr, timeStr) {
        if (!dateStr || !timeStr) return '';
        const date = new Date(`${dateStr}T${timeStr}`);
        return date.toLocaleDateString() + ' ' + date.toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'});
    }

    getValueClass(value) {
        if (value > 0) return 'positive';
        if (value < 0) return 'negative';
        return 'neutral';
    }

    validateInputs(values) {
        for (let i = 0; i < values.length; i++) {
            const value = values[i];
            if (value === '' || value === null || value === undefined) {
                console.log('Empty value found at index', i, ':', value);
                return false;
            }
            if (typeof value === 'number' && isNaN(value)) {
                console.log('NaN value found at index', i, ':', value);
                return false;
            }
        }
        return true;
    }

    getFormValue(id) {
        const element = document.getElementById(id);
        return element ? element.value : '';
    }

    calculateSettlement() {
        try {
            console.log('Starting settlement calculation...');

            // Get form values using helper method
            const entryDate = this.getFormValue('entry-date-1');
            const entryTime = this.getFormValue('entry-time-1');
            const entryFuturesStr = this.getFormValue('entry-futures-1');
            const entrySpotStr = this.getFormValue('entry-spot-1');
            const contractsStr = this.getFormValue('contracts-1');
            const exitDate = this.getFormValue('exit-date-1');
            const exitTime = this.getFormValue('exit-time-1');
            const exitFuturesStr = this.getFormValue('exit-futures-1');
            const exitSpotStr = this.getFormValue('exit-spot-1');

            console.log('Form values retrieved:', {
                entryDate, entryTime, entryFuturesStr, entrySpotStr, contractsStr,
                exitDate, exitTime, exitFuturesStr, exitSpotStr
            });

            // Parse numeric values
            const entryFutures = parseFloat(entryFuturesStr);
            const entrySpot = parseFloat(entrySpotStr);
            const contracts = parseInt(contractsStr);
            const exitFutures = parseFloat(exitFuturesStr);
            const exitSpot = parseFloat(exitSpotStr);

            console.log('Parsed values:', {
                entryFutures, entrySpot, contracts, exitFutures, exitSpot
            });

            // Validate inputs
            if (!this.validateInputs([entryDate, entryTime, entryFutures, entrySpot, contracts, exitDate, exitTime, exitFutures, exitSpot])) {
                alert('Please fill in all required fields with valid values.');
                return;
            }

            // Validate date/time
            const entryDateEl = document.getElementById('entry-date-1');
            const entryTimeEl = document.getElementById('entry-time-1');
            const exitDateEl = document.getElementById('exit-date-1');
            const exitTimeEl = document.getElementById('exit-time-1');
            if (!this.validateDateTime(entryDateEl, entryTimeEl, exitDateEl, exitTimeEl, 'Exit date/time must be after entry date/time')) {
                return;
            }

            // Perform calculations
            const initialPremium = this.calculateInitialPremium(entryFutures, entrySpot, contracts);
            const exitPremium = this.calculateExitPremium(exitFutures, exitSpot, contracts);
            const netPremium = this.calculateNetPremium(initialPremium, exitPremium);
            const portfolioValueAtExit = this.calculatePortfolioValueAtExit(exitSpot, contracts);
            const daysHeld = this.calculatePreciseDaysDifference(entryDate, entryTime, exitDate, exitTime);
            const baseReturn = this.calculateBaseReturn(netPremium, portfolioValueAtExit);
            const annualizedReturn = this.calculateAnnualizedReturn(baseReturn, daysHeld);
            const premiumPerContract = this.calculatePremiumPerContract(netPremium, contracts);

            const results = {
                type: 'Settlement',
                entryDate,
                entryTime,
                exitDate,
                exitTime,
                entryFutures,
                entrySpot,
                exitFutures,
                exitSpot,
                contracts,
                initialPremium,
                exitPremium,
                netPremium,
                daysHeld,
                baseReturn,
                annualizedReturn,
                premiumPerContract,
                portfolioValueAtExit
            };

            console.log('Settlement calculation completed:', results);
            this.currentResults.settlement = results;

            // Display results and enable save button
            this.displaySettlementResults(results);
            this.enableSaveButton('save-settlement');

        } catch (error) {
            console.error('Settlement calculation error:', error);
            alert('Error calculating settlement: ' + error.message);
        }
    }

    calculateBuyback() {
        try {
            console.log('Starting buyback calculation...');

            // Get form values using helper method
            const entryDate = this.getFormValue('entry-date-2');
            const entryTime = this.getFormValue('entry-time-2');
            const entryFuturesStr = this.getFormValue('entry-futures-2');
            const entrySpotStr = this.getFormValue('entry-spot-2');
            const contractsStr = this.getFormValue('contracts-2');
            const exitDate = this.getFormValue('exit-date-2');
            const exitTime = this.getFormValue('exit-time-2');
            const exitFuturesStr = this.getFormValue('exit-futures-2');
            const exitSpotStr = this.getFormValue('exit-spot-2');

            // Parse numeric values
            const entryFutures = parseFloat(entryFuturesStr);
            const entrySpot = parseFloat(entrySpotStr);
            const contracts = parseInt(contractsStr);
            const exitFutures = parseFloat(exitFuturesStr);
            const exitSpot = parseFloat(exitSpotStr);

            // Validate inputs
            if (!this.validateInputs([entryDate, entryTime, entryFutures, entrySpot, contracts, exitDate, exitTime, exitFutures, exitSpot])) {
                alert('Please fill in all required fields with valid values.');
                return;
            }

            // Validate date/time
            const entryDateEl = document.getElementById('entry-date-2');
            const entryTimeEl = document.getElementById('entry-time-2');
            const exitDateEl = document.getElementById('exit-date-2');
            const exitTimeEl = document.getElementById('exit-time-2');
            if (!this.validateDateTime(entryDateEl, entryTimeEl, exitDateEl, exitTimeEl, 'Exit date/time must be after entry date/time')) {
                return;
            }

            // Perform calculations
            const initialPremium = this.calculateInitialPremium(entryFutures, entrySpot, contracts);
            const exitPremium = this.calculateExitPremium(exitFutures, exitSpot, contracts);
            const netPremium = this.calculateNetPremium(initialPremium, exitPremium);
            const portfolioValueAtExit = this.calculatePortfolioValueAtExit(exitSpot, contracts);
            const daysHeld = this.calculatePreciseDaysDifference(entryDate, entryTime, exitDate, exitTime);
            const baseReturn = this.calculateBaseReturn(netPremium, portfolioValueAtExit);
            const annualizedReturn = this.calculateAnnualizedReturn(baseReturn, daysHeld);
            const premiumPerContract = this.calculatePremiumPerContract(netPremium, contracts);

            const results = {
                type: 'Buyback',
                entryDate,
                entryTime,
                exitDate,
                exitTime,
                entryFutures,
                entrySpot,
                exitFutures,
                exitSpot,
                contracts,
                initialPremium,
                exitPremium,
                netPremium,
                daysHeld,
                baseReturn,
                annualizedReturn,
                premiumPerContract,
                portfolioValueAtExit
            };

            console.log('Buyback calculation completed:', results);
            this.currentResults.buyback = results;

            // Display results and enable save button
            this.displayBuybackResults(results);
            this.enableSaveButton('save-buyback');

        } catch (error) {
            console.error('Buyback calculation error:', error);
            alert('Error calculating buyback: ' + error.message);
        }
    }

    displaySettlementResults(results) {
        const {
            initialPremium,
            exitPremium,
            netPremium,
            daysHeld,
            baseReturn,
            annualizedReturn,
            premiumPerContract
        } = results;

        console.log('Displaying settlement results...');

        // Update result elements
        this.updateElement('initial-premium-1', this.formatCurrency(initialPremium), this.getValueClass(initialPremium));
        this.updateElement('exit-premium-1', this.formatCurrency(exitPremium), this.getValueClass(exitPremium));
        this.updateElement('net-premium-1', this.formatCurrency(netPremium), this.getValueClass(netPremium));
        this.updateElement('days-held-1', this.formatDays(daysHeld), 'neutral');
        this.updateElement('base-return-1', this.formatPercentage(baseReturn), this.getValueClass(baseReturn));
        this.updateElement('annualized-return-1', this.formatPercentage(annualizedReturn), this.getValueClass(annualizedReturn));
        this.updateElement('premium-per-contract-1', this.formatCurrency(premiumPerContract), this.getValueClass(premiumPerContract));

        // Show results with animation
        this.showResults('settlement-results');
    }

    displayBuybackResults(results) {
        const {
            initialPremium,
            exitPremium,
            netPremium,
            daysHeld,
            baseReturn,
            annualizedReturn,
            premiumPerContract
        } = results;

        console.log('Displaying buyback results...');

        // Update result elements
        this.updateElement('initial-premium-2', this.formatCurrency(initialPremium), this.getValueClass(initialPremium));
        this.updateElement('exit-premium-2', this.formatCurrency(exitPremium), this.getValueClass(exitPremium));
        this.updateElement('net-premium-2', this.formatCurrency(netPremium), this.getValueClass(netPremium));
        this.updateElement('days-held-2', this.formatDays(daysHeld), 'neutral');
        this.updateElement('base-return-2', this.formatPercentage(baseReturn), this.getValueClass(baseReturn));
        this.updateElement('annualized-return-2', this.formatPercentage(annualizedReturn), this.getValueClass(annualizedReturn));
        this.updateElement('premium-per-contract-2', this.formatCurrency(premiumPerContract), this.getValueClass(premiumPerContract));

        // Show results with animation
        this.showResults('buyback-results');
    }

    updateElement(id, text, className) {
        const element = document.getElementById(id);
        if (element) {
            element.textContent = text;
            element.className = `result-value ${className}`;
            console.log(`Updated element ${id} with value: ${text}, class: ${className}`);
        } else {
            console.warn(`Element with id ${id} not found`);
        }
    }

    showResults(resultsId) {
        const resultsDiv = document.getElementById(resultsId);
        if (resultsDiv) {
            console.log(`Showing results div: ${resultsId}`);
            resultsDiv.classList.remove('hidden');
            resultsDiv.classList.add('show-animation');
            
            // Scroll to results
            setTimeout(() => {
                resultsDiv.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
            }, 100);
            
            console.log(`Results displayed for: ${resultsId}`);
        } else {
            console.warn(`Results div with id ${resultsId} not found`);
        }
    }

    enableSaveButton(buttonId) {
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = false;
            console.log(`Enabled save button: ${buttonId}`);
        }
    }

    saveCalculation(type) {
        const result = this.currentResults[type];
        if (!result) {
            alert('No calculation to save. Please calculate first.');
            return;
        }

        // Add timestamp and unique ID
        const savedResult = {
            ...result,
            id: Date.now().toString(),
            timestamp: new Date().toISOString()
        };

        this.savedCalculations.push(savedResult);
        this.updateComparisonTable();
        
        this.showExportStatus(`${type} calculation saved successfully!`);
        
        // Disable save button after saving
        const buttonId = type === 'settlement' ? 'save-settlement' : 'save-buyback';
        const button = document.getElementById(buttonId);
        if (button) {
            button.disabled = true;
        }
        
        console.log('Calculation saved:', savedResult);
    }

    updateComparisonTable() {
        const noCalculationsDiv = document.getElementById('no-calculations');
        const tableContainer = document.getElementById('calculations-table');
        const tbody = document.getElementById('calculations-tbody');

        console.log('Updating comparison table, calculations count:', this.savedCalculations.length);

        if (!tbody) {
            console.warn('Table body not found');
            return;
        }

        if (this.savedCalculations.length === 0) {
            if (noCalculationsDiv) noCalculationsDiv.classList.remove('hidden');
            if (tableContainer) tableContainer.classList.add('hidden');
            return;
        }

        if (noCalculationsDiv) noCalculationsDiv.classList.add('hidden');
        if (tableContainer) tableContainer.classList.remove('hidden');

        // Clear existing rows
        tbody.innerHTML = '';

        // Add rows for each saved calculation
        this.savedCalculations.forEach((calc, index) => {
            const row = this.createTableRow(calc, index);
            tbody.appendChild(row);
        });
        
        console.log('Table updated with', this.savedCalculations.length, 'calculations');
    }

    createTableRow(calc, index) {
        const row = document.createElement('tr');
        row.className = index === this.savedCalculations.length - 1 ? 'table-row-new' : '';
        
        const entryDateTime = this.formatDateTime(calc.entryDate, calc.entryTime);
        const exitDateTime = this.formatDateTime(calc.exitDate, calc.exitTime);
        
        row.innerHTML = `
            <td>
                <span class="trade-type-${calc.type.toLowerCase()}">${calc.type}</span>
            </td>
            <td class="datetime-display">${entryDateTime}</td>
            <td class="datetime-display">${exitDateTime}</td>
            <td>${calc.contracts}</td>
            <td class="time-precision">${this.formatDays(calc.daysHeld)}</td>
            <td class="${this.getValueClass(calc.netPremium)}">${this.formatCurrency(calc.netPremium)}</td>
            <td class="${this.getValueClass(calc.annualizedReturn)}">${this.formatPercentage(calc.annualizedReturn)}</td>
            <td>
                <button class="delete-btn" onclick="calculator.deleteCalculation('${calc.id}')" title="Delete calculation">
                    Delete
                </button>
            </td>
        `;
        
        return row;
    }

    deleteCalculation(id) {
        if (confirm('Are you sure you want to delete this calculation?')) {
            this.savedCalculations = this.savedCalculations.filter(calc => calc.id !== id);
            this.updateComparisonTable();
            this.showExportStatus('Calculation deleted successfully!');
        }
    }

    clearAllCalculations() {
        if (this.savedCalculations.length === 0) {
            alert('No calculations to clear.');
            return;
        }
        
        if (confirm(`Are you sure you want to delete all ${this.savedCalculations.length} saved calculations?`)) {
            this.savedCalculations = [];
            this.updateComparisonTable();
            this.showExportStatus('All calculations cleared successfully!');
        }
    }

    exportToCSV() {
        if (this.savedCalculations.length === 0) {
            alert('No calculations to export.');
            return;
        }

        const headers = [
            'Trade Type', 'Entry Date', 'Entry Time', 'Exit Date', 'Exit Time',
            'Contracts', 'Entry Futures Price', 'Entry Spot Price', 
            'Exit Futures Price', 'Exit Spot Price', 'Days Held',
            'Initial Premium', 'Exit Premium', 'Net Premium',
            'Base Return (%)', 'Annualized Interest Rate (%)', 'Premium per Contract'
        ];

        const rows = this.savedCalculations.map(calc => [
            calc.type,
            calc.entryDate,
            calc.entryTime,
            calc.exitDate,
            calc.exitTime,
            calc.contracts,
            calc.entryFutures.toFixed(2),
            calc.entrySpot.toFixed(2),
            calc.exitFutures.toFixed(2),
            calc.exitSpot.toFixed(2),
            calc.daysHeld.toFixed(4),
            calc.initialPremium.toFixed(2),
            calc.exitPremium.toFixed(2),
            calc.netPremium.toFixed(2),
            (calc.baseReturn * 100).toFixed(4),
            (calc.annualizedReturn * 100).toFixed(4),
            calc.premiumPerContract.toFixed(2)
        ]);

        const csvContent = [headers, ...rows]
            .map(row => row.map(field => `"${field}"`).join(','))
            .join('\n');

        const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
        const link = document.createElement('a');
        const url = URL.createObjectURL(blob);
        link.setAttribute('href', url);
        link.setAttribute('download', `gold_futures_calculations_${new Date().toISOString().split('T')[0]}.csv`);
        link.style.visibility = 'hidden';
        document.body.appendChild(link);
        link.click();
        document.body.removeChild(link);
        
        this.showExportStatus('Calculations exported to CSV successfully!');
    }

    showExportStatus(message) {
        // Create or update status div
        let statusDiv = document.getElementById('export-status');
        if (!statusDiv) {
            statusDiv = document.createElement('div');
            statusDiv.id = 'export-status';
            statusDiv.className = 'export-status';
            document.body.appendChild(statusDiv);
        }
        
        statusDiv.textContent = message;
        statusDiv.classList.add('show');
        
        // Hide after 3 seconds
        setTimeout(() => {
            statusDiv.classList.remove('show');
        }, 3000);
        
        console.log('Status message shown:', message);
    }
}

// Initialize calculator when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    console.log('DOM loaded, initializing calculator...');
    window.calculator = new GoldFuturesCalculator();
    console.log('Calculator initialized and stored in window.calculator');
});