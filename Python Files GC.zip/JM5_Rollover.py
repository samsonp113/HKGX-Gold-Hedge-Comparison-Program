import pandas as pd
from datetime import datetime
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows

header_row = 1
MIN_VOL = 1500

# --- GCJ5 (April "J") - BUY/COVER window (example: March 1–March 31) ---
gcj5_file = "GCJ5_Spot.xlsx"
gcj5_sheet = "Spot_GCJ5"
gcj5_time_col = "Date.1"
gcj5_px_col = "Open.1"
gcj5_vol_col = "GCJ5 Volume"
gcj5_buy_start = datetime(2025, 3, 1)
gcj5_buy_end   = datetime(2025, 3, 31)

# --- GCM5 (June "M") - SELL/SHORT window (March 1–March 31) ---
gcm5_file = "GCM5_Spot.xlsx"
gcm5_sheet = "Spot_GCM5"
gcm5_time_col = "Date.1"
gcm5_px_col = "Open.1"
gcm5_vol_col = "GCM5 Volume"
gcm5_sell_start = datetime(2025, 3, 1)
gcm5_sell_end   = datetime(2025, 3, 31)

spot_time_col = "Date"
spot_px_col = "Open"
output_file = "hedge_roll_jm_ratio.xlsx"

def load_contract(file, sheet, fut_time_col, fut_px_col, fut_vol_col, start, end):
    df = pd.read_excel(file, sheet_name=sheet, header=header_row)
    fut = df[[fut_time_col, fut_px_col, fut_vol_col]].dropna()
    fut = fut.rename(columns={
        fut_time_col: "Fut_Time",
        fut_px_col: "Fut_Price",
        fut_vol_col: "Fut_Vol"
    })
    fut['Fut_Time'] = pd.to_datetime(fut['Fut_Time'])
    fut = fut[fut['Fut_Time'].dt.hour.isin([21, 22, 23, 0, 1])]
    fut = fut[(fut['Fut_Time'] >= start) & (fut['Fut_Time'] <= end)]
    spot = df[[spot_time_col, spot_px_col]].dropna()
    spot = spot.rename(columns={spot_time_col: "Spot_Time", spot_px_col: "Spot_Price"})
    spot['Spot_Time'] = pd.to_datetime(spot['Spot_Time'])
    fut["Year"] = fut['Fut_Time'].dt.year
    fut["Month"] = fut['Fut_Time'].dt.month
    fut["Day"] = fut['Fut_Time'].dt.day
    fut["Hour"] = fut['Fut_Time'].dt.hour
    spot["Year"] = spot['Spot_Time'].dt.year
    spot["Month"] = spot['Spot_Time'].dt.month
    spot["Day"] = spot['Spot_Time'].dt.day
    spot["Hour"] = spot['Spot_Time'].dt.hour
    merged = pd.merge(
        fut, spot[["Year", "Month", "Day", "Hour", "Spot_Price"]],
        on=["Year", "Month", "Day", "Hour"], how="inner"
    )
    merged["Spread"] = merged["Fut_Price"] - merged["Spot_Price"]
    merged = merged[merged["Fut_Vol"] >= MIN_VOL].sort_values("Fut_Time").reset_index(drop=True)
    return merged

# Load J buys (covers) and M sells (shorts)
j_buys = load_contract(
    gcj5_file, gcj5_sheet, gcj5_time_col, gcj5_px_col, gcj5_vol_col,
    gcj5_buy_start, gcj5_buy_end
)
m_sells = load_contract(
    gcm5_file, gcm5_sheet, gcm5_time_col, gcm5_px_col, gcm5_vol_col,
    gcm5_sell_start, gcm5_sell_end
)

# Match on exact date+hour
m_sells_by_time = m_sells.set_index("Fut_Time")

rows = []
for _, j in j_buys.iterrows():
    t = j["Fut_Time"]
    if t in m_sells_by_time.index:
        m = m_sells_by_time.loc[t]
        j_spread = j["Spread"]
        m_spread = m["Spread"]
        if j_spread > 0 and m_spread > 0:
            spread_ratio = m_spread / j_spread if j_spread != 0 else None
            rows.append([
                t,
                j["Spot_Price"],
                j["Fut_Price"], j_spread, j["Fut_Vol"],
                m["Fut_Price"], m_spread, m["Fut_Vol"],
                spread_ratio
            ])
roll_df = pd.DataFrame(rows, columns=[
    "DateTime", "Spot_Price",
    "J_Buy_FutPrice", "J_Buy_Spread", "J_Buy_Volume",
    "M_Sell_FutPrice", "M_Sell_Spread", "M_Sell_Volume",
    "M_div_J_Spread_Ratio"
])

# Sort and show top 100
roll_df = roll_df.sort_values("M_div_J_Spread_Ratio", ascending=False).head(100).reset_index(drop=True)

# Output Excel
wb = openpyxl.Workbook()
wb.remove(wb.active)
def to_sheet(df, name):
    ws = wb.create_sheet(name)
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
to_sheet(roll_df, "RollOptions_JBuy_MSell")
wb.save(output_file)
print(f"Saved: {output_file} | Matches: {len(roll_df)}")
