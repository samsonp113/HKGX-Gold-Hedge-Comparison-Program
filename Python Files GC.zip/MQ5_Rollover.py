import pandas as pd
from datetime import datetime
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows

header_row = 1
MIN_VOL = 1500

# --- GCM5 (buy/cover window in May) ---
gcm5_file = "GCM5_Spot.xlsx"
gcm5_sheet = "Spot_GCM5"
gcm5_time_col = "Date.1"
gcm5_px_col = "Open.1"
gcm5_vol_col = "GCM5 Volume"
gcm5_buy_start = datetime(2025, 5, 1)
gcm5_buy_end   = datetime(2025, 5, 31)

# --- GCQ5 (sell/short window in May) ---
gcq5_file = "GCQ5_Spot.xlsx"
gcq5_sheet = "Spot_GCQ5"
gcq5_time_col = "Date.1"
gcq5_px_col = "Open.1"
gcq5_vol_col = "GCQ5 Volume"
gcq5_sell_start = datetime(2025, 5, 1)
gcq5_sell_end   = datetime(2025, 5, 31)

spot_time_col = "Date"
spot_px_col = "Open"
output_file = "mq_options.xlsx"

def load_contract(file, sheet, fut_time_col, fut_px_col, fut_vol_col, start, end):
    df = pd.read_excel(file, sheet_name=sheet, header=header_row)
    fut = df[[fut_time_col, fut_px_col, fut_vol_col]].dropna()
    fut = fut.rename(columns={
        fut_time_col: "Fut_Time",
        fut_px_col: "Fut_Price",
        fut_vol_col: "Fut_Vol"
    })
    fut['Fut_Time'] = pd.to_datetime(fut['Fut_Time'])
    fut = fut[fut['Fut_Time'].dt.hour.isin([21, 22, 23, 0, 1])]
    fut = fut[(fut['Fut_Time'] >= start) & (fut['Fut_Time'] <= end)]
    spot = df[[spot_time_col, spot_px_col]].dropna()
    spot = spot.rename(columns={spot_time_col: "Spot_Time", spot_px_col: "Spot_Price"})
    spot['Spot_Time'] = pd.to_datetime(spot['Spot_Time'])
    # Match on calendar hour
    fut["Year"] = fut['Fut_Time'].dt.year
    fut["Month"] = fut['Fut_Time'].dt.month
    fut["Day"] = fut['Fut_Time'].dt.day
    fut["Hour"] = fut['Fut_Time'].dt.hour
    spot["Year"] = spot['Spot_Time'].dt.year
    spot["Month"] = spot['Spot_Time'].dt.month
    spot["Day"] = spot['Spot_Time'].dt.day
    spot["Hour"] = spot['Spot_Time'].dt.hour
    merged = pd.merge(
        fut, spot[["Year", "Month", "Day", "Hour", "Spot_Price"]],
        on=["Year", "Month", "Day", "Hour"], how="inner"
    )
    merged["Spread"] = merged["Fut_Price"] - merged["Spot_Price"]
    merged = merged[merged["Fut_Vol"] >= MIN_VOL].sort_values("Fut_Time").reset_index(drop=True)
    return merged

# Load both contracts' May windows
m_buys = load_contract(
    gcm5_file, gcm5_sheet, gcm5_time_col, gcm5_px_col, gcm5_vol_col, gcm5_buy_start, gcm5_buy_end
)
q_sells = load_contract(
    gcq5_file, gcq5_sheet, gcq5_time_col, gcq5_px_col, gcq5_vol_col, gcq5_sell_start, gcq5_sell_end
)

# Match on exact date+hour: build DataFrames indexed by Fut_Time for fast matching
q_sells_by_time = q_sells.set_index("Fut_Time")

rows = []
for _, m in m_buys.iterrows():
    t = m["Fut_Time"]
    if t in q_sells_by_time.index:
        q = q_sells_by_time.loc[t]
        m_spread = m["Spread"]
        q_spread = q["Spread"]
        # Only positive spreads to avoid silly ratios/negatives/zero division
        if m_spread > 0 and q_spread > 0:
            # Ratio: Q_spread / M_spread (Q must be higher for good rolls)
            spread_ratio = q_spread / m_spread if m_spread != 0 else None
            rows.append([
                t,
                m["Spot_Price"],
                m["Fut_Price"], m["Spread"], m["Fut_Vol"],
                q["Fut_Price"], q["Spread"], q["Fut_Vol"],
                spread_ratio
            ])
roll_df = pd.DataFrame(rows, columns=[
    "DateTime", "Spot_Price",
    "M_Buy_FutPrice", "M_Buy_Spread", "M_Buy_Volume",
    "Q_Sell_FutPrice", "Q_Sell_Spread", "Q_Sell_Volume",
    "Q_div_M_Spread_Ratio"
])

# Sort and show ALL rows, ranked by highest ratio
roll_df = roll_df.sort_values("Q_div_M_Spread_Ratio", ascending=False).reset_index(drop=True)

# Output all possible matched roll options
wb = openpyxl.Workbook()
wb.remove(wb.active)
def to_sheet(df, name):
    ws = wb.create_sheet(name)
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
to_sheet(roll_df, "RollOptions_MBuy_QSell")
wb.save(output_file)
print(f"Saved: {output_file} | Matches: {len(roll_df)}")
