import pandas as pd
from datetime import datetime
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows

header_row = 1
MIN_VOL = 1500

# --- GCQ5 (August "Q"): buy/cover window (example: September 1–September 30) ---
gcq5_file = "GCQ5_Spot.xlsx"
gcq5_sheet = "Spot_GCQ5"
gcq5_time_col = "Date.1"
gcq5_px_col = "Open.1"
gcq5_vol_col = "GCQ5 Volume"
gcq5_buy_start = datetime(2025, 7, 1)
gcq5_buy_end   = datetime(2025, 7, 30)

# --- GCZ5 (December "Z"): sell/short window (September 1–September 30 as well) ---
gcz5_file = "GCZ5_Spot.xlsx"
gcz5_sheet = "Spot_GCZ5"
gcz5_time_col = "Date.1"
gcz5_px_col = "Open.1"
gcz5_vol_col = "GCZ5 Volume"
gcz5_sell_start = datetime(2025, 7, 1)
gcz5_sell_end   = datetime(2025, 7, 30)

spot_time_col = "Date"
spot_px_col = "Open"
output_file = "hedge_roll_qz_options.xlsx"

def load_contract(file, sheet, fut_time_col, fut_px_col, fut_vol_col, start, end):
    df = pd.read_excel(file, sheet_name=sheet, header=header_row)
    fut = df[[fut_time_col, fut_px_col, fut_vol_col]].dropna()
    fut = fut.rename(columns={
        fut_time_col: "Fut_Time",
        fut_px_col: "Fut_Price",
        fut_vol_col: "Fut_Vol"
    })
    fut['Fut_Time'] = pd.to_datetime(fut['Fut_Time'])
    fut = fut[fut['Fut_Time'].dt.hour.isin([21, 22, 23, 0, 1])]
    fut = fut[(fut['Fut_Time'] >= start) & (fut['Fut_Time'] <= end)]
    spot = df[[spot_time_col, spot_px_col]].dropna()
    spot = spot.rename(columns={spot_time_col: "Spot_Time", spot_px_col: "Spot_Price"})
    spot['Spot_Time'] = pd.to_datetime(spot['Spot_Time'])
    # Match on calendar hour
    fut["Year"] = fut['Fut_Time'].dt.year
    fut["Month"] = fut['Fut_Time'].dt.month
    fut["Day"] = fut['Fut_Time'].dt.day
    fut["Hour"] = fut['Fut_Time'].dt.hour
    spot["Year"] = spot['Spot_Time'].dt.year
    spot["Month"] = spot['Spot_Time'].dt.month
    spot["Day"] = spot['Spot_Time'].dt.day
    spot["Hour"] = spot['Spot_Time'].dt.hour
    merged = pd.merge(
        fut, spot[["Year", "Month", "Day", "Hour", "Spot_Price"]],
        on=["Year", "Month", "Day", "Hour"], how="inner"
    )
    merged["Spread"] = merged["Fut_Price"] - merged["Spot_Price"]
    merged = merged[merged["Fut_Vol"] >= MIN_VOL].sort_values("Fut_Time").reset_index(drop=True)
    return merged

# Load both contracts' roll windows
q_buys = load_contract(
    gcq5_file, gcq5_sheet, gcq5_time_col, gcq5_px_col, gcq5_vol_col, gcq5_buy_start, gcq5_buy_end
)
z_sells = load_contract(
    gcz5_file, gcz5_sheet, gcz5_time_col, gcz5_px_col, gcz5_vol_col, gcz5_sell_start, gcz5_sell_end
)

# Match on exact date+hour
z_sells_by_time = z_sells.set_index("Fut_Time")

rows = []
for _, q in q_buys.iterrows():
    t = q["Fut_Time"]
    if t in z_sells_by_time.index:
        z = z_sells_by_time.loc[t]
        q_spread = q["Spread"]
        z_spread = z["Spread"]
        if q_spread > 0 and z_spread > 0:
            spread_ratio = z_spread / q_spread if q_spread != 0 else None
            rows.append([
                t,
                q["Spot_Price"],
                q["Fut_Price"], q["Spread"], q["Fut_Vol"],
                z["Fut_Price"], z["Spread"], z["Fut_Vol"],
                spread_ratio
            ])
roll_df = pd.DataFrame(rows, columns=[
    "DateTime", "Spot_Price",
    "Q_Buy_FutPrice", "Q_Buy_Spread", "Q_Buy_Volume",
    "Z_Sell_FutPrice", "Z_Sell_Spread", "Z_Sell_Volume",
    "Z_div_Q_Spread_Ratio"
])

# Sort and show ALL matches, ranked by highest ratio
roll_df = roll_df.sort_values("Z_div_Q_Spread_Ratio", ascending=False).reset_index(drop=True)

# OPTIONAL: Show only top 100
roll_df = roll_df.head(100)

# Output all possible matched roll options
wb = openpyxl.Workbook()
wb.remove(wb.active)
def to_sheet(df, name):
    ws = wb.create_sheet(name)
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
to_sheet(roll_df, "RollOptions_QBuy_ZSell")
wb.save(output_file)
print(f"Saved: {output_file} | Matches: {len(roll_df)}")
