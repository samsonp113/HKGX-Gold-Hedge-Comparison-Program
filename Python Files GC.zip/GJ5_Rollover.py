import pandas as pd
from datetime import datetime
import openpyxl
from openpyxl.utils.dataframe import dataframe_to_rows

header_row = 1
MIN_VOL = 1500

# --- GCG5 (Feb "G") - BUY/COVER window: March (rolling out in March) ---
gcg5_file = "GCG5_Spot.xlsx"
gcg5_sheet = "Spot_GCG5"
gcg5_time_col = "Date.1"
gcg5_px_col = "Open.1"
gcg5_vol_col = "GCG5 Volume"
gcg5_buy_start = datetime(2025, 1, 1)
gcg5_buy_end   = datetime(2025, 1, 31)

# --- GCJ5 (Apr "J") - SELL/SHORT window: March (rolling in during March) ---
gcj5_file = "GCJ5_Spot.xlsx"
gcj5_sheet = "Spot_GCJ5"
gcj5_time_col = "Date.1"
gcj5_px_col = "Open.1"
gcj5_vol_col = "GCJ5 Volume"
gcj5_sell_start = datetime(2025, 1, 1)
gcj5_sell_end   = datetime(2025, 1, 31)

spot_time_col = "Date"
spot_px_col = "Open"
output_file = "hedge_roll_gj_ratio.xlsx"

def load_contract(file, sheet, fut_time_col, fut_px_col, fut_vol_col, start, end):
    df = pd.read_excel(file, sheet_name=sheet, header=header_row)
    fut = df[[fut_time_col, fut_px_col, fut_vol_col]].dropna()
    fut = fut.rename(columns={
        fut_time_col: "Fut_Time",
        fut_px_col: "Fut_Price",
        fut_vol_col: "Fut_Vol"
    })
    fut['Fut_Time'] = pd.to_datetime(fut['Fut_Time'])
    fut = fut[fut['Fut_Time'].dt.hour.isin([21, 22, 23, 0, 1])]
    fut = fut[(fut['Fut_Time'] >= start) & (fut['Fut_Time'] <= end)]
    spot = df[[spot_time_col, spot_px_col]].dropna()
    spot = spot.rename(columns={spot_time_col: "Spot_Time", spot_px_col: "Spot_Price"})
    spot['Spot_Time'] = pd.to_datetime(spot['Spot_Time'])
    fut["Year"] = fut['Fut_Time'].dt.year
    fut["Month"] = fut['Fut_Time'].dt.month
    fut["Day"] = fut['Fut_Time'].dt.day
    fut["Hour"] = fut['Fut_Time'].dt.hour
    spot["Year"] = spot['Spot_Time'].dt.year
    spot["Month"] = spot['Spot_Time'].dt.month
    spot["Day"] = spot['Spot_Time'].dt.day
    spot["Hour"] = spot['Spot_Time'].dt.hour
    merged = pd.merge(
        fut, spot[["Year", "Month", "Day", "Hour", "Spot_Price"]],
        on=["Year", "Month", "Day", "Hour"], how="inner"
    )
    merged["Spread"] = merged["Fut_Price"] - merged["Spot_Price"]
    merged = merged[merged["Fut_Vol"] >= MIN_VOL].sort_values("Fut_Time").reset_index(drop=True)
    return merged

# Load G buys (covers) and J sells (shorts)
g_buys = load_contract(
    gcg5_file, gcg5_sheet, gcg5_time_col, gcg5_px_col, gcg5_vol_col,
    gcg5_buy_start, gcg5_buy_end
)
j_sells = load_contract(
    gcj5_file, gcj5_sheet, gcj5_time_col, gcj5_px_col, gcj5_vol_col,
    gcj5_sell_start, gcj5_sell_end
)

# Match by exact date+hour and compute spread ratio
j_sells_by_time = j_sells.set_index("Fut_Time")
rows = []
for _, g in g_buys.iterrows():
    t = g["Fut_Time"]
    if t in j_sells_by_time.index:
        j = j_sells_by_time.loc[t]
        g_spread = g["Spread"]
        j_spread = j["Spread"]
        if g_spread > 0 and j_spread > 0:
            spread_ratio = j_spread / g_spread if g_spread != 0 else None
            rows.append([
                t,
                g["Spot_Price"],
                g["Fut_Price"], g_spread, g["Fut_Vol"],
                j["Fut_Price"], j_spread, j["Fut_Vol"],
                spread_ratio
            ])

roll_df = pd.DataFrame(rows, columns=[
    "DateTime", "Spot_Price",
    "G_Buy_FutPrice", "G_Buy_Spread", "G_Buy_Volume",
    "J_Sell_FutPrice", "J_Sell_Spread", "J_Sell_Volume",
    "J_div_G_Spread_Ratio"
])

roll_df = roll_df.sort_values("J_div_G_Spread_Ratio", ascending=False).head(100).reset_index(drop=True)

# Output Excel
wb = openpyxl.Workbook()
wb.remove(wb.active)
def to_sheet(df, name):
    ws = wb.create_sheet(name)
    for r in dataframe_to_rows(df, index=False, header=True):
        ws.append(r)
to_sheet(roll_df, "RollOptions_GBuy_JSell")
wb.save(output_file)
print(f"Saved: {output_file} | Matches: {len(roll_df)}")
